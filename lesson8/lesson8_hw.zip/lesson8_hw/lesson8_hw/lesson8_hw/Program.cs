﻿using lesson8_hw.Models;
using lesson8_hw.Repository;
using lesson8_hw.Services;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace lesson8_hw
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var context = new MyContext())
            {
                Console.WriteLine("\n*** מוסיף לקוח חדש ***");
                var newClient = new Client
                {
                    ClientId = 104,
                    FirstName = "dodi",
                    Phone = "055222222"
                };

                context.Clients.Add(newClient);
                context.SaveChanges();
                Console.WriteLine("לקוח נוסף בהצלחה.");

                Console.WriteLine("\n*** מוסיף דירה חדשה ***");
                var newApartment = new Apartment
                {
                    ApartmentId = 5,
                    Address = "agasi",
                    RentPrice = 4500,
                    IsAvailable = true
                };

                context.Apartments.Add(newApartment);
                context.SaveChanges();
                Console.WriteLine("נוספה דירה חדשה.");

                Console.WriteLine("\n*** כל הדירות ***");
                var allApartments = context.Apartments.ToList();

                foreach (var a in allApartments)
                {
                    Console.WriteLine($"ID: {a.ApartmentId}, כתובת: {a.Address}, מחיר: {a.RentPrice}, פנוי: {a.IsAvailable}");
                }

                string ClientName = "moshe";
                Console.WriteLine($"\n*** דירות עבור הלקוח {ClientName} ***");

                var apartmentsForClient = context.Interests
                    .Include(i => i.Apartment)
                    .Include(i => i.Client)
                    .Where(i => i.Client.FirstName == ClientName)
                    .Select(i => i.Apartment)
                    .ToList();

                if (apartmentsForClient.Any())
                {
                    foreach (var a in apartmentsForClient)
                    {
                        Console.WriteLine($"ID: {a.ApartmentId}, כתובת: {a.Address}, מחיר: {a.RentPrice}, פנוי: {a.IsAvailable}");
                    }
                }
                else
                {
                    Console.WriteLine($"הלקוח {ClientName} אינו קיים");
                }


                var clientRepo = new ClientRepository(context);
                var apartmentRepo = new ApartmentRepository(context);

                var clientService = new ClientService(clientRepo);
                var apartmentService = new ApartmentService(apartmentRepo);

                clientService.AddClient(new Client
                {
                    ClientId = 1,
                    FirstName = "David",
                    Phone = "0501234567"
                });

                var c = clientService.GetClient(1);
                Console.WriteLine(c.FirstName);
            }

            Console.ReadLine();
        }
    }
}
