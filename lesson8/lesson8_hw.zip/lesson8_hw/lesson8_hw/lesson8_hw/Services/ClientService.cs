﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lesson8_hw.Models;
using lesson8_hw.Repository;

namespace lesson8_hw.Services
{
    public class ClientService
    {
        private readonly IClientRepository _repo;

        public ClientService(IClientRepository repo)
        {
            _repo = repo;
        }

        public void AddClient(Client c)
        {
            _repo.Add(c);
        }

        public Client GetClient(int id)
        {
            return _repo.GetById(id);
        }
    }
}
