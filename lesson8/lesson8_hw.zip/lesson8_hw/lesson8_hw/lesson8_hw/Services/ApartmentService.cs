﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using lesson8_hw.Models;
using lesson8_hw.Repository;

namespace lesson8_hw.Services
{
    public class ApartmentService
    {
        private readonly IApartmentRepository _repo;

        public ApartmentService(IApartmentRepository repo)
        {
            _repo = repo;
        }

        public void AddApartment(Apartment a)
        {
            _repo.Add(a);
        }

        public Apartment GetApartment(int id)
        {
            return _repo.GetById(id);
        }
    }
}
