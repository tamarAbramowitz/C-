﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lesson8_hw.Models;

namespace lesson8_hw.Repository
{
    public class ClientRepository : IClientRepository
    {
        private readonly MyContext _context;

        public ClientRepository(MyContext context)
        {
            _context = context;
        }

        public Client GetById(int id)
        {
            return _context.Clients.Find(id);
        }

        public void Add(Client client)
        {
            _context.Clients.Add(client);
            _context.SaveChanges();
        }
    }
}
