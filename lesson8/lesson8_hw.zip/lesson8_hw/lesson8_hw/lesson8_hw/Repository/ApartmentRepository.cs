﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using lesson8_hw.Models;

namespace lesson8_hw.Repository
{
    public class ApartmentRepository : IApartmentRepository
    {
        private readonly MyContext _context;

        public ApartmentRepository(MyContext context)
        {
            _context = context;
        }

        public Apartment GetById(int id)
        {
            return _context.Apartments.Find(id);
        }

        public void Add(Apartment apartment)
        {
            _context.Apartments.Add(apartment);
            _context.SaveChanges();
        }
    }
}
