﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lesson8_hw.Models;


namespace lesson8_hw.Repository
{
    public interface IClientRepository
    {
        Client GetById(int id);
        void Add(Client client);
    }
}



