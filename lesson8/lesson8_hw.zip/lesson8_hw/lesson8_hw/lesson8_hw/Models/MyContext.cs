﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace lesson8_hw.Models;

public partial class MyContext : DbContext
{
    public MyContext()
    {
    }

    public MyContext(DbContextOptions<MyContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Apartment> Apartments { get; set; }

    public virtual DbSet<Client> Clients { get; set; }

    public virtual DbSet<Interest> Interests { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    => optionsBuilder.UseSqlServer(
        "Data Source=(LocalDB)\\MSSQLLocalDB;" +
        "AttachDbFilename=C:\\Users\\Tamar\\Desktop\\lesson8_hw\\MYOB.mdf;" +
        "Integrated Security=True;Connect Timeout=30");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Apartment>(entity =>
        {
            entity.Property(e => e.ApartmentId).ValueGeneratedNever();
            entity.Property(e => e.Address)
                .HasMaxLength(50)
                .UseCollation("SQL_Latin1_General_CP1_CI_AS");
        });

        modelBuilder.Entity<Client>(entity =>
        {
            entity.Property(e => e.ClientId).ValueGeneratedNever();
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .UseCollation("SQL_Latin1_General_CP1_CI_AS");
            entity.Property(e => e.Phone)
                .HasMaxLength(10)
                .UseCollation("SQL_Latin1_General_CP1_CI_AS");
        });

        modelBuilder.Entity<Interest>(entity =>
        {
            entity.HasKey(e => e.InterestId).HasName("PK__Interest__20832C67D1B4A183");

            entity.Property(e => e.InterestId).ValueGeneratedNever();

            entity.HasOne(d => d.Apartment).WithMany(p => p.Interests)
                .HasForeignKey(d => d.ApartmentId)
                .HasConstraintName("FK_Interests_Apartment");

            entity.HasOne(d => d.Client).WithMany(p => p.Interests)
                .HasForeignKey(d => d.ClientId)
                .HasConstraintName("FK_Interests_Client");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
