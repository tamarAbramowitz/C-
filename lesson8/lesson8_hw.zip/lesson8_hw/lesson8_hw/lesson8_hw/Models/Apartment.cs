﻿using System;
using System.Collections.Generic;


using System.Collections.Generic;

namespace lesson8_hw.Models
{
    public partial class Apartment
    {
        public int ApartmentId { get; set; }
        public string? Address { get; set; }
        public int? RentPrice { get; set; }
        public bool? IsAvailable { get; set; }
        public virtual ICollection<Interest> Interests { get; set; } = new HashSet<Interest>();
    }
}



