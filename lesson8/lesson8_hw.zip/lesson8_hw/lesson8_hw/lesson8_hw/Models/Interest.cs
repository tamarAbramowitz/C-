﻿using System;
using System.Collections.Generic;

namespace lesson8_hw.Models;

public partial class Interest
{
    public int InterestId { get; set; }

    public int? ClientId { get; set; }

    public int? ApartmentId { get; set; }

    public DateTime? InterestDate { get; set; }

    public virtual Apartment? Apartment { get; set; }

    public virtual Client? Client { get; set; }
}
