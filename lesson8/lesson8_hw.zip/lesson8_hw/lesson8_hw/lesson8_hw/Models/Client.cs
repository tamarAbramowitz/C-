﻿using System;
using System.Collections.Generic;

namespace lesson8_hw.Models;

public partial class Client
{
    public int ClientId { get; set; }

    public string? FirstName { get; set; }

    public string? Phone { get; set; }

    public virtual ICollection<Interest> Interests { get; set; } = new List<Interest>();
}
